package com.lzx.RandomForest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author: 如寄
 * @version: v1.0
 * @description: com.test
 * @date:2021/4/1
 */
public class ReadXOrC {
    public static List<String> readData(File file) throws IOException {
        List<String> list = new ArrayList<String>();
        String fileName = file.getName();
        // csv 后缀名
        if (fileName.endsWith("csv")) {
            DataInputStream in = new DataInputStream(new FileInputStream(file));
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, "GBK"));//换成你的文件名
            reader.readLine();//第一行信息，为标题信息，不用，如果需要，注释掉
            String line = null;
            while ((line = reader.readLine()) != null) {
                String item[] = line.split("，");//CSV格式文件为逗号分隔符文件，这里根据逗号切分
                String content = "";
                for (int i = 0; i < item.length; i++)
                    content += item[i] + ",";
                list.add(content);
            }
        } else { // xlsx后缀名
            InputStream is = new FileInputStream(file);
            XSSFWorkbook xworkBook = new XSSFWorkbook(is);
            XSSFSheet sheet = xworkBook.getSheetAt(0);
            int firstRowIndex = sheet.getFirstRowNum() + 1;   //第一行是列名，所以不读
            int lastRowIndex = sheet.getLastRowNum();
            for (int rIndex = firstRowIndex; rIndex <= lastRowIndex; rIndex++) {   //遍历行
                Row row = sheet.getRow(rIndex);
                if (row != null) {
                    Cell cell0 = row.getCell(0);
                    Cell cell1 = row.getCell(1);
                    if (cell0 == null || cell1 == null)
                        continue;
                    list.add(cell0.getStringCellValue() + "," + cell1.getStringCellValue());
                }
            }
            xworkBook.close();
            is.close();
        }
        return list;
    }
}
