package com.lzx.RandomForest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author: 如寄
 * @version: v1.0
 * @description: com.lzx.test
 * @date:2021/4/18
 */
public class ReadFile {
    public String[] types = {"财经", "房产", "教育", "科技", "军事", "汽车", "体育", "游戏", "娱乐", "其它"};

    //    读取训练好的模型数据
    public static List<String> read() throws IOException {
        String str = null;
        List<String> list = new ArrayList<>();
        File file = new File("随机森林\\tree.txt");
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
        while ((str = bufferedReader.readLine()) != null) {
            list.add(str);
        }
        bufferedReader.close();
        return list;
    }
}
