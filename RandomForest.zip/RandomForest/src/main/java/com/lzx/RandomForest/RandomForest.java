package com.lzx.RandomForest;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * @author: 如寄
 * @version: v1.0
 * @description: com.新闻分类.RandomForest
 * @date:2021/5/20
 */
public class RandomForest {
    private static String[] types = {"财经", "房产", "教育", "科技", "军事", "汽车", "体育", "游戏", "娱乐", "其它"};
    private TermUtils termUtils = new TermUtils();
    private int i = 0;
    private List<TreeNode> forest = null;

    public RandomForest() throws IOException {
        forest = getForest();
    }

    public List<TreeNode> getForest() throws IOException {
        List<String> tree = ReadFile.read();
        List<TreeNode> treeNodes = new ArrayList<>();
        for (String s : tree) {
            TreeNode treeNode = buildTree(s.split(" "));
            treeNodes.add(treeNode);
            i = 0;
        }
        return treeNodes;
    }

    //单条新闻分类
    public String ClassificationNew(String content, int num) throws IOException {
        Map<String, Boolean> map = toMap(content);
        Map<String, Integer> typeMap = new HashMap<>();
        for (int i = 0; i < num; i++) {
            String type = dfs(forest.get(i), map);
            if (typeMap.containsKey(type)) {
                typeMap.replace(type, typeMap.get(type) + 1);
            } else typeMap.put(type, 1);
        }
        //bagging投票
        int temp = 0;
        String type = null;
        for (Map.Entry<String, Integer> entry : typeMap.entrySet()) {
            if (entry.getValue() >= temp) {
                type = entry.getKey();
                temp = entry.getValue();
            }
        }
        return type;
    }

    public List<String> classificationAll(File file) throws IOException {
        List<String> list = ReadXOrC.readData(file);
        List<String> classification = new ArrayList<>();
        for (String s : list) {
            String type = ClassificationNew(s, 94);
            classification.add(type);
        }
        return classification;
    }

    public Map<String, Boolean> toMap(String content) throws IOException {
        Map<String, Boolean> map = new HashMap<>();
        List<String> list = termUtils.RemoveOfStopWord(content);
        for (String S : list) {
            map.put(S, true);
        }
        return map;
    }

    //建树
    public TreeNode buildTree(String[] tree) {
        if (tree[i].equals("#")) {
            i++;
            return null;
        }
        TreeNode index = new TreeNode(tree[i++]);
        index.left = buildTree(tree);
        index.right = buildTree(tree);
        return index;
    }

    public String dfs(TreeNode index, Map<String, Boolean> map) {
        if (index.right == null && index.left == null)
            return index.node;
        if (map.containsKey(index.node)) {
            return dfs(index.left, map);
        }
        return dfs(index.right, map);
    }
}
