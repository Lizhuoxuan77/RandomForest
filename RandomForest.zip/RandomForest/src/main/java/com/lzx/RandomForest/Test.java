package com.lzx.RandomForest;


import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * @author: 如寄
 * @version: v1.0
 * @description: com.新闻分类.rocchio
 * @date:2021/5/17
 */
public class Test {
    public static void main(String[] args) throws Exception {
        String[] types = {"财经", "房产", "教育", "科技", "军事", "汽车", "体育", "游戏", "娱乐", "其它"};
        RandomForestTrain randomForestTrain = new RandomForestTrain();

        randomForestTrain.createForest("D:\\User\\新闻分类\\训练数据", "D:\\User\\新闻分类\\测试数据", types, 100);
    }
}
