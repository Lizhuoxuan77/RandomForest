package com.lzx.RandomForest;

/**
 * @author: 如寄
 * @version: v1.0
 * @description: com.lzx.决策树模型
 * @date:2021/5/12
 */
public class TreeNode {
    String node;//节点值
    String forecast;//节点预测类型
    TreeNode left;//左子树
    TreeNode right;//右子树

    public TreeNode(String node) {
        this.node = node;
        left = null;
        right = null;
    }

    public void setForecast(String forecast) {
        this.forecast = forecast;
    }

    public String getForecast() {
        return forecast;
    }
}
