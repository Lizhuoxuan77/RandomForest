package com.lzx.RandomForest;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

/**
 * @author: 如寄
 * @version: v1.0
 * @description: com.新闻分类.RandomForest
 * @date:2021/5/20
 */
public class RandomForestTrain {
    public TermUtils termUtils = new TermUtils();

    /*
    trainDataDir：训练数据的目录
    testDataDir：测试数据的目录，主要用于过拟合处理
    classType：数据的类型，根据类型读取数据目录下各个类型的数据
    treeAmount：森林中树的数量
     */
    public void createForest(String trainDataDir, String testDataDir, String classType[], Integer treeAmount) throws Exception {
        System.out.println("开始读训练数据！");
        Map<String, List<Map<String, Boolean>>> trainData = readData(trainDataDir, classType);
        System.out.println("开始读测试数据！");
        Map<String, List<Map<String, Boolean>>> testData = readData(testDataDir, classType);
        List<String> trees = new ArrayList<>();
        for (int i = 0; i < treeAmount; i++) {
            CreateTree createTree = new CreateTree();
            String tree = createTree.buildTree(trainData, testData);
            trees.add(tree);
            System.out.println(i);
        }
        FileWriter fileWriter = new FileWriter(new File("随机森林\\tree.txt"));
        for (String tree : trees) {
            fileWriter.write(tree + "\n");
        }
        fileWriter.close();
    }

    //    读取新闻数据
    private Map<String, List<Map<String, Boolean>>> readData(String dir, String[] classType) throws Exception {
        Map<String, List<Map<String, Boolean>>> ans = new HashMap<>();
        for (int index = 0; index < classType.length; index++) {
            List<String> list = ReadXOrC.readData(new File(dir + "\\" + classType[index] + ".xlsx"));
            Map<String, Boolean> map;
            List<Map<String, Boolean>> list1 = new ArrayList<>();
            for (String s : list) {
                map = toMap(s);
                list1.add(map);
            }
            System.out.println("读了:" + list.size() + "条数据");
            ans.put(classType[index], list1);
        }
        return ans;

    }


    //    把内容做分词去掉停词处理，以Map形式返回
    public Map<String, Boolean> toMap(String content) throws IOException {
        Map<String, Boolean> map = new HashMap<>();
        List<String> list = termUtils.RemoveOfStopWord(content);
        for (String S : list) {
            map.put(S, true);
        }
        return map;
    }
}
