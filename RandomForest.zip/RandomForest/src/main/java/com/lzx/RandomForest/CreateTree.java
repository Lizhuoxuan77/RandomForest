package com.lzx.RandomForest;


import java.io.IOException;
import java.util.*;

/**
 * @author: 如寄
 * @version: v1.0
 * @date:2021/5/11
 */
public class CreateTree {
    public String tree;
    public Map<String, Boolean> visit = new HashMap<>();//记录已经访问过的特征

    public String buildTree(Map<String, List<Map<String, Boolean>>> data, Map<String, List<Map<String, Boolean>>> testData) throws IOException, InterruptedException {
        TreeNode node = dfs(data);
        cut(node, testData);
        tree = "";
        search(node);
        System.out.println(tree);
        System.out.println("$$$");
        return tree;
    }

    //剪枝、防止过拟合
    private int cut(TreeNode node, Map<String, List<Map<String, Boolean>>> testData) {
        if (node.left == null && node.right == null) {
            return testData.containsKey(node.getForecast()) ? testData.get(node.getForecast()).size() : 0;
        }
        //计算剪枝后的正确数
        int a = testData.containsKey(node.getForecast()) ? testData.get(node.getForecast()).size() : 0;
        //计算不剪枝的正确数
        int l = cut(node.left, getLeft(node.node, testData));
        int r = cut(node.right, getRight(node.node, testData));
        if (a >= (l + r)) {//判断是否剪枝
            node.node = node.getForecast();
            node.right = null;
            node.left = null;
        }
        return Math.max(a, l + r);
    }

    //中序遍历
    private void search(TreeNode node) {
        if (node == null) {
            tree += "# ";
            return;
        }
        tree += node.node + " ";
        search(node.left);
        search(node.right);
    }

    TreeNode dfs(Map<String, List<Map<String, Boolean>>> data) throws IOException, InterruptedException {
        List<Map<String, Integer>> featureList = new ArrayList<>();//每个类型的特征集
        Map<String, Integer> wholeMap = new HashMap<>();//数据集中所有特征的集
        List<Integer> eachTypeNumber = new ArrayList<>();//每个类型数据的数量
        int allSum = 0;//所有数据的数量
        if (data.size() <= 1) { //数据类型只有一个的时候树停止生长，以此类型作为叶子节点
            for (Map.Entry<String, List<Map<String, Boolean>>> entry : data.entrySet()) {
                eachTypeNumber.add(entry.getValue().size());
            }
            String type = getType(eachTypeNumber, data);
            TreeNode node = new TreeNode(type);
            node.setForecast(type);
            return node;
        }
        for (Map.Entry<String, List<Map<String, Boolean>>> entry1 : data.entrySet()) {
            List<Map<String, Boolean>> list = entry1.getValue();
            Map<String, Integer> res = new HashMap<String, Integer>();
            for (Map<String, Boolean> map : list) {
                for (Map.Entry<String, Boolean> entry : map.entrySet()) {
                    if (res.containsKey(entry.getKey())) {
                        res.replace(entry.getKey(), res.get(entry.getKey()) + 1);
                    } else res.put(entry.getKey(), 1);
                }
            }
            for (Map.Entry<String, Integer> entry : res.entrySet()) {
                if (wholeMap.containsKey(entry.getKey())) {
                    wholeMap.replace(entry.getKey(), wholeMap.get(entry.getKey()) + entry.getValue());
                } else wholeMap.put(entry.getKey(), entry.getValue());
            }
            featureList.add(res);
            allSum += list.size();
            eachTypeNumber.add(list.size());
        }
        String feature = null;
        Map<String, Double> temp = getGain(wholeMap, eachTypeNumber, featureList, allSum);
        feature = getRandomFeature(temp);
        String type = getType(eachTypeNumber, data);
        if (feature == null) {
            TreeNode node = new TreeNode(type);
            node.setForecast(type);
            return node;
        }
        TreeNode node = new TreeNode(feature);
        node.setForecast(type);
        visit.put(feature, true);
        Map<String, List<Map<String, Boolean>>> left = getLeft(feature, data);
        Map<String, List<Map<String, Boolean>>> right = getRight(feature, data);
        node.left = dfs(left);
        node.right = dfs(right);
        visit.remove(feature);
        return node;
    }

    //获取随机特征
    private String getRandomFeature(Map<String, Double> temp) {
        List<Map.Entry<String, Double>> lst = new ArrayList<Map.Entry<String, Double>>(temp.entrySet());
        Collections.sort(lst, new Comparator<Map.Entry<String, Double>>() {
            @Override
            public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
                if (o1.getValue() > o2.getValue()) return -1;
                if (o1.getValue() < o2.getValue()) return 1;
                return 0;
            }
        });
        Random random = new Random();
        int i = (int) Math.sqrt(lst.size());
        if (i > 0) {
            i = random.nextInt(i);
            return lst.get(i).getKey();
        }
        return null;
    }

    //计算信息增益
    private Map<String, Double> getGain(Map<String, Integer> wholeMap, List<Integer> eachTypeNumber, List<Map<String, Integer>> featureList, int allSum) {
        Map<String, Double> temp = new HashMap<>();
        double ED = getEnt(allSum, eachTypeNumber);
        for (Map.Entry<String, Integer> entry : wholeMap.entrySet()) {
            double e1 = getLeEnt(entry.getValue(), featureList, entry.getKey());
            double e2 = getReEnt(allSum - entry.getValue(), featureList, entry.getKey(), eachTypeNumber);
            //计算信息增益gain
            double gain = ED - ((entry.getValue() * 1.0 / allSum) * e1 + ((allSum - entry.getValue()) * 1.0 / allSum) * e2);
            if (!visit.containsKey(entry.getKey()) && !entry.getKey().equals("\n") && !entry.getKey().equals("")) {
                temp.put(entry.getKey(), gain);
            }
        }
        return temp;
    }

    /*
    获得次节点上数据类型最多的类型
     */
    public String getType(List<Integer> allList, Map<String, List<Map<String, Boolean>>> ans) {
        String type = "其它";
        int temp = 0, i = 0;
        for (Map.Entry<String, List<Map<String, Boolean>>> entry : ans.entrySet()) {
            if (allList.get(i) > temp) {
                type = entry.getKey();
                temp = allList.get(i);
            }
            i++;
        }
        return type;
    }

    /*
    获得此节点上包含特征feature的数据
     */
    public Map<String, List<Map<String, Boolean>>> getLeft(String feature, Map<String, List<Map<String, Boolean>>> res) {
        Map<String, List<Map<String, Boolean>>> ans = new HashMap<>();
        for (Map.Entry<String, List<Map<String, Boolean>>> entry : res.entrySet()) {
            List<Map<String, Boolean>> mapList = entry.getValue();
            List<Map<String, Boolean>> list = new ArrayList<>();
            for (Map<String, Boolean> map : mapList) {
                if (map.containsKey(feature)) {
                    list.add(map);
                }
            }
            if (list.size() > 0) {
                ans.put(entry.getKey(), list);
            }
        }
        return ans;
    }

    /*
    获得此节点上不包含特征feature的数据
     */
    public Map<String, List<Map<String, Boolean>>> getRight(String feature, Map<String, List<Map<String, Boolean>>> res) {
        Map<String, List<Map<String, Boolean>>> ans = new HashMap<>();
        for (Map.Entry<String, List<Map<String, Boolean>>> entry : res.entrySet()) {
            List<Map<String, Boolean>> mapList = entry.getValue();
            List<Map<String, Boolean>> list = new ArrayList<>();
            for (Map<String, Boolean> map : mapList) {
                if (!map.containsKey(feature)) {
                    list.add(map);
                }
            }
            if (list.size() > 0) {
                ans.put(entry.getKey(), list);
            }
        }
        return ans;
    }

    /*
    计算不包含特征feature的信息熵
     */
    private static double getReEnt(int value, List<Map<String, Integer>> listS, String feature, List<Integer> allList) {
        if (value == 0)
            return 0;
        double res = 0;
        int i = 0;
        for (Map<String, Integer> map : listS) {
            if (map.containsKey(feature)) {
                res += (allList.get(i) - map.get(feature) + 1) * 1.0 / value * Math.log((allList.get(i) - map.get(feature) + 1) * 1.0 / value);
            } else res += allList.get(i) * 1.0 / value * Math.log(allList.get(i) * 1.0 / value);
            i++;
        }
        return -res;
    }

    /*
    计算包含特征feature的信息熵
     */
    private static double getLeEnt(int value, List<Map<String, Integer>> listS, String feature) {
        double res = 0;
        for (Map<String, Integer> map : listS) {
            if (map.containsKey(feature)) {
                res += map.get(feature) * 1.0 / value * Math.log(map.get(feature) * 1.0 / value);
            }
        }
        return -res;
    }

    /*
    计算数据集的信息熵
     */
    private static double getEnt(int allSum, List<Integer> allList) {
        double res = 0;
        for (Integer integer : allList) {
            res += integer * 1.0 / allSum * Math.log(integer * 1.0 / allSum);
        }
        return -res;
    }

}
